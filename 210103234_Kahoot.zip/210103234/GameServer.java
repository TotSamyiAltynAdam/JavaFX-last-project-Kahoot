package com.example.thirdproject;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.FontPosture;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class GameServer extends Application {
    private static int clientCount = 1;
    private static final int pinCode = (int)(Math.random()*7778);
    private static final String rightAnswer = "You wrote right pinCode!";
    private static final String wrongAnswer = "Wrong pinCode!";
    private static HashMap<String, Integer> players = new HashMap<>();

    private static BorderPane root;
    private static final Font font = Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 16);
    private static final double HEIGHT = 400., WIDTH = 500.;
    private static Button buttonStart;
    private static boolean strive = false;
    private static boolean pauseForStrive = false;

    private static int currentSec = 13;
    private static final int tempForCurrentSec = 13;
    public static Scene scene;
    private static final String[] colors = {"red", "blue", "orange", "green"};

    private static Quiz quiz;
    private static Questions view;
    public static int index = 0;
    public static int react = 0;

    private static int countForRedColor = 0;
    private static int countForBlueColor = 0;
    private static int countForOrangeColor = 0;
    private static int countForGreenColor = 0;
    private static int countForRightFillAnswer = 0;

    private static File mediaFile;
    private static MediaPlayer mediaPlayer;
    private static Media media;


    @Override
    public void start(Stage stage) throws FileNotFoundException {
        root = new BorderPane();
        StackPane stackPane = new StackPane();
        Button chooseButton = new Button("ChooseFile");

        Image image = new Image(new FileInputStream("src/background.jpg"));
        ImageView imageView = new ImageView(image);
        imageView.fitWidthProperty().bind(root.widthProperty());
        imageView.fitHeightProperty().bind(root.heightProperty());

        chooseButton.setOnAction(e -> {
            try {
//                FileChooser fileChooser = new FileChooser();
//                File file = fileChooser.showOpenDialog(stage);
                dosMusic();
                mediaPlayer.play();
                afterChoosing(root,stage);
                File file = new File("C:\\Users\\Елдос Анарбаев\\IdeaProjects\\thirdProject\\src\\main\\java\\com\\example\\thirdproject\\Quiz.txt");
                quiz = Quiz.loadFromFile(file.getPath());

            } catch (IOException ex) {
                ex.getStackTrace();
                System.exit(-1);
            } catch (InvalidFormatException ex) {
                String s = ex.getMessage();
                root.setCenter(new Label(s));
            }
        });
        stackPane.getChildren().addAll(imageView,chooseButton);
        stage.setTitle("Choose file");

        root.setCenter(stackPane);

        scene = new Scene(root, WIDTH, HEIGHT);
        stage.setScene(scene);
        stage.show();
    }

    public void afterChoosing(BorderPane root,Stage stage){
//        Image image = new Image(new FileInputStream("src/welcomeForKahoot.jpg"));
//        ImageView imageView = new ImageView(image);
//        imageView.fitWidthProperty().bind(root.widthProperty().divide(1.5));
//        imageView.fitHeightProperty().bind(root.heightProperty().divide(2));
        root.getChildren().clear();
        root.setStyle("-fx-background-color: steelBlue");

        Label labelForPinCode = new Label();
        labelForPinCode.setText("  Join at www.kahoot.it or with the Kahoot! app  \n"
                + "  with Game PIN:\n"
                + "  " + pinCode);
        labelForPinCode.setAlignment(Pos.CENTER);
        labelForPinCode.setFont(font);
        labelForPinCode.prefHeightProperty().bind(root.heightProperty().divide(7));
        labelForPinCode.prefWidthProperty().bind(root.widthProperty());
        labelForPinCode.setStyle("-fx-background-color: white");
        labelForPinCode.setTextFill(Color.BLACK);

        Label labelWaitingPlayer = new Label();
        labelWaitingPlayer.prefWidthProperty().bind(root.widthProperty());
        labelWaitingPlayer.prefHeightProperty().bind(root.heightProperty().divide(10));
        labelWaitingPlayer.setText("    (!)Waiting for players...");
        labelWaitingPlayer.setFont(font);
        labelWaitingPlayer.setTextFill(Color.WHITE);
        labelWaitingPlayer.setStyle("-fx-background-color: darkBlue");

        Label labelCountPlayers = new Label();
        labelCountPlayers.setText("       " + (clientCount - 1) + "\n Players");
        labelCountPlayers.setFont(font);
        labelCountPlayers.setTextFill(Color.DARKBLUE);

        buttonStart = new Button("Start");
        buttonStart.setFont(font);
        buttonStart.setTextFill(Color.WHITE);
        buttonStart.setStyle("-fx-background-color: gray");

        buttonStart.setOnAction(e -> {
            strive = true;
            System.out.println("I am server and i am boss, and we will start");
            try {
                serverShow(stage);
            } catch (FileNotFoundException ex) {
                ex.getStackTrace();
            }
        });

        StackPane stackPaneForCenterName = new StackPane();
        HBox hBoxForPlayersName = new HBox();
        hBoxForPlayersName.setAlignment(Pos.CENTER);
        stackPaneForCenterName.getChildren().add(hBoxForPlayersName);

        BorderPane.setAlignment(labelForPinCode, Pos.CENTER);
//        BorderPane.setAlignment(imageView, Pos.CENTER);
        BorderPane.setAlignment(labelCountPlayers, Pos.CENTER);
        BorderPane.setAlignment(buttonStart, Pos.CENTER);
        BorderPane.setAlignment(hBoxForPlayersName,Pos.CENTER);

        root.setTop(labelForPinCode);
//        root.setCenter(imageView);
        root.setCenter(stackPaneForCenterName);
        root.setBottom(labelWaitingPlayer);
        root.setLeft(labelCountPlayers);
        root.setRight(buttonStart);

        new Thread(() -> {
            try {
                ServerSocket server = new ServerSocket(9898);
                System.out.println("We are waiting a clients!");

                while (true) {

                    Socket socket = server.accept();
                    System.out.println(clientCount + " client come in.");

                    new Thread(() -> {
                        try {
                            DataInputStream fromPlayer = new DataInputStream(socket.getInputStream());
                            DataOutputStream toPlayer = new DataOutputStream(socket.getOutputStream());

                            checkPinCode(fromPlayer, toPlayer);
                            String playerName = getPlayerName(fromPlayer, toPlayer);
                            Platform.runLater(() -> {
                                clientCount++;
                                labelCountPlayers.setText("     " + (clientCount - 1) + "\n Players");

                                Label labelForNames = new Label(playerName + "  ");
                                labelForNames.setTextFill(Color.WHITE);
                                labelForNames.setFont(font);
                                hBoxForPlayersName.getChildren().addAll(labelForNames);
                            });

                            while (true) {
                                if (isStrive()) {
                                    toPlayer.writeUTF("strive");
                                    toPlayer.writeUTF(quiz.getQuestions().get(index).getType()+"");
                                    break;
                                }
                            }

                            boolean[] flag = {true};
                            while (true) {
                                if (isStrive() && !isPauseForStrive()) {
                                    toPlayer.writeUTF("give me answer");
                                    getAnswer(playerName, fromPlayer, toPlayer, flag);
                                }

                                if (isPauseForStrive()) {
                                    System.out.println("PausaStrive!!!");
                                    toPlayer.writeUTF("time out");
                                    toPlayer.writeUTF(players.get(playerName) + "");

                                    flag[0] = true;

                                    while (isPauseForStrive()) {
                                        continue;
                                    }
                                    if(strive) {
                                        toPlayer.writeUTF(quiz.getQuestions().get(index).getType() + "");
                                    }else{
                                        System.out.println("end");
                                        toPlayer.writeUTF("end");
                                    }
                                }
                            }
                        } catch (IOException e) {
                            e.getStackTrace();
                        }

                    }).start();
                }
            } catch (IOException e) {
                e.getStackTrace();
            }

        }).start();

        stage.setTitle("GameServer");
    }


    public static void checkPinCode(DataInputStream fromPlayer, DataOutputStream toPlayer) throws IOException {
        while (true) {
            int pinCodeFromPlayer = fromPlayer.readInt();
            if (pinCode != pinCodeFromPlayer) {
                toPlayer.writeUTF(wrongAnswer);
                toPlayer.flush();
                System.out.println("Wrong pinCode!");
            } else {
                toPlayer.writeUTF(rightAnswer);
                toPlayer.flush();
                System.out.println("YOu are right!");
                break;
            }

        }
    }

    public static String getPlayerName(DataInputStream fromPlayer, DataOutputStream toPlayer) throws IOException {
        String playerName = fromPlayer.readUTF();
        System.out.println("User name is: " + playerName);

        players.put(playerName, 0);

        // TODO: I added everyone players in this map for evaluate grades each of them in the future

        toPlayer.writeUTF(playerName);
        toPlayer.flush();

        return playerName;
    }

    public static void getAnswer(String playerName, DataInputStream fromPlayer, DataOutputStream toPlayer, boolean[] flag) throws IOException {
        Question q = quiz.getQuestions().get(index);

        if(q.getType()==2) {
            getTextAnswer(playerName, fromPlayer, toPlayer, flag);
        }
        if(q.getType()==1) {
            getFillAnswer(playerName,fromPlayer,toPlayer,flag);
        }
    }

    public static void getTextAnswer(String playerName, DataInputStream fromPlayer, DataOutputStream toPlayer, boolean[] flag) throws IOException {
        String rightAnswer = quiz.getQuestions().get(index).getAnswer();

        Question q = quiz.getQuestions().get(index);
        Test t = (Test)q;

        String answerFromTest = fromPlayer.readUTF();


        if(rightAnswer.equals("A")){
            rightAnswer = t.getOptionAt(0);
        }
        if(rightAnswer.equals("B")){
            rightAnswer = t.getOptionAt(1);
        }
        if(rightAnswer.equals("C")){
            rightAnswer = t.getOptionAt(2);
        }
        if(rightAnswer.equals("D")){
            rightAnswer = t.getOptionAt(3);
        }

        if (!answerFromTest.equals("") && flag[0]) {

            if(answerFromTest.equals("red")){
                answerFromTest = t.getOptionAt(0);
                countForRedColor++;
            }
            if(answerFromTest.equals("blue")){
                answerFromTest = t.getOptionAt(1);
                countForBlueColor++;
            }
            if(answerFromTest.equals("orange")){
                answerFromTest = t.getOptionAt(2);
                countForOrangeColor++;
            }
            if(answerFromTest.equals("green")){
                answerFromTest = t.getOptionAt(3);
                countForGreenColor++;
            }

            if(answerFromTest.equals(rightAnswer)){
                int p = players.get(playerName);
                p += 200;

                players.put(playerName, p);
            }
            react++;
            System.out.println(playerName + " choose a " + answerFromTest + " color");
            flag[0] = false;
        }


    }

    public static void getFillAnswer(String playerName,DataInputStream fromPlayer, DataOutputStream toPlayer,boolean[] flag) throws IOException {
        String rightAnswer = quiz.getQuestions().get(index).getAnswer();

        String answerFromTest = fromPlayer.readUTF();

        if (!answerFromTest.equals("") && flag[0]) {
            if (answerFromTest.equals(rightAnswer)) {
                int p = players.get(playerName);
                p += 200;
                countForRightFillAnswer++;
                players.put(playerName, p);
            }

            react++;
            System.out.println(playerName + ": typed this.... " + answerFromTest);
            flag[0] = false;
        }
    }

    public static void serverShow(Stage stage) throws FileNotFoundException {
        Label labelForTime = new Label();
        labelForTime.setText("" + currentSec);

        Label labelFotReact = new Label();
        labelFotReact.setText("" + react + "\n answer");
        labelFotReact.setFont(font);

        Timeline timeline = new Timeline();
        timeline.setCycleCount(Animation.INDEFINITE);


        Question q = quiz.getQuestions().get(index);

        timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (currentSec == 0) {
                    pauseForStrive = true;
                    if(q.getType()==2) {
                        showPlace(root, stage, quiz.getQuestions().get(index));
                    }

                    if(q.getType()==1){
                        showPlaceForFill(root,stage,quiz.getQuestions().get(index));
                    }

                    timeline.pause();
                } else {
                    labelForTime.setText("" + (--currentSec));
                    labelFotReact.setText("" + react + "\n answer");
                }
            }
        }));

        timeline.play();
        view = new Questions(quiz,root, stage, labelForTime, labelFotReact,index);
        view.go();

    }


    public static void showPlace(BorderPane root, Stage stage,Question question) {

        HBox boxPaneForQuestion = new HBox();

        Label labelNumQuestion = new Label();
        Label labelIch = new Label();

        labelNumQuestion.setText("Q" + (++index));
        labelIch.setText(" ich");
        labelNumQuestion.setTextFill(Color.ORANGE);
        labelIch.setTextFill(Color.BLACK);

        boxPaneForQuestion.setStyle("-fx-background-color: white");
        boxPaneForQuestion.setAlignment(Pos.CENTER);
        boxPaneForQuestion.setSpacing(5);
        boxPaneForQuestion.getChildren().addAll(labelNumQuestion, labelIch);

        Rectangle forRed = new Rectangle(25,90,30,10 + (countForRedColor*10));
        forRed.setArcHeight(15);
        forRed.setArcWidth(25);
        forRed.setFill(Color.RED);

        Rectangle forBlue = new Rectangle(25,90,30,10 + (countForBlueColor*10));
        forBlue.setArcHeight(15);
        forBlue.setArcWidth(25);
        forBlue.setFill(Color.BLUE);

        Rectangle forOrange = new Rectangle(25,90,30,10 + (countForOrangeColor*10));
        forOrange.setArcHeight(15);
        forOrange.setArcWidth(25);
        forOrange.setFill(Color.ORANGE);

        Rectangle forGreen = new Rectangle(25,90,30,10 + (countForGreenColor*10));
        forGreen.setArcHeight(15);
        forGreen.setArcWidth(25);
        forGreen.setFill(Color.GREEN);

        HBox hBoxForRectangles = new HBox();
        hBoxForRectangles.getChildren().addAll(forRed,forBlue,forOrange,forGreen);
        hBoxForRectangles.setSpacing(WIDTH/4.54);
        hBoxForRectangles.setAlignment(Pos.CENTER_LEFT);

        Label labelForRedColor = new Label();
        Label labelForBlueColor = new Label();
        Label labelForOrangeColor = new Label();
        Label labelForGreenColor = new Label();

        labelForBlueColor.setText("blue: " + countForBlueColor );
        labelForRedColor.setText("red: " + countForRedColor);
        labelForOrangeColor.setText("orange: " + countForOrangeColor);
        labelForGreenColor.setText("green: " + countForGreenColor);

        labelForRedColor.setTextFill(Color.RED);
        labelForBlueColor.setTextFill(Color.BLUE);
        labelForOrangeColor.setTextFill(Color.ORANGE);
        labelForGreenColor.setTextFill(Color.GREEN);


        HBox hBoxForCount = new HBox();
        hBoxForCount.getChildren().addAll(labelForRedColor,labelForBlueColor,labelForOrangeColor,labelForGreenColor);
        hBoxForCount.setSpacing(WIDTH/5.3);
        hBoxForCount.setAlignment(Pos.BOTTOM_LEFT);

        VBox vBoxForCenterResult = new VBox();
        vBoxForCenterResult.setAlignment(Pos.CENTER);
        vBoxForCenterResult.getChildren().addAll(hBoxForRectangles,hBoxForCount);

        Button nextButton = new Button("Next->");
        nextButton.setTextFill(Color.WHITE);
        nextButton.setStyle("-fx-background-color: purple");

        nextButton.setOnAction(e -> {
            try {
                currentSec = tempForCurrentSec;

                react = 0;
                countForRedColor = 0;
                countForBlueColor = 0;
                countForOrangeColor = 0;
                countForGreenColor = 0;

                if(index == quiz.getQuestions().size()){
                    strive = false;
                    pauseForStrive = false;
                    dosMusic();
                    mediaPlayer.pause();
                    totalPage(root,stage);
                }else {
                    pauseForStrive = false;
                    serverShow(stage);
                }
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        });

        HBox hBox1 = new HBox();
        hBox1.setAlignment(Pos.CENTER);
        hBox1.setSpacing(5);
        hBox1.setMinSize(100, 80);

        HBox hBox2 = new HBox();
        hBox2.setAlignment(Pos.CENTER);
        hBox2.setSpacing(5);
        hBox2.setMinSize(100, 80);

        HBox[] hBoxes = {hBox1, hBox2};

        Test t = (Test)question;

        for (int i = 0; i < 4; i++) {
            Label labelForAnswers = new Label();
            labelForAnswers.setText(t.getOptionAt(i));
            labelForAnswers.setFont(font);
            labelForAnswers.prefWidthProperty().bind(hBoxes[i / 2].widthProperty().divide(2));
            labelForAnswers.prefHeightProperty().bind(hBoxes[i / 2].heightProperty());
            labelForAnswers.setStyle("-fx-background-color: " + colors[i]);
            hBoxes[i / 2].getChildren().add(labelForAnswers);
        }

        VBox vBoxesForAnswers = new VBox();
        vBoxesForAnswers.setSpacing(5);
        vBoxesForAnswers.prefWidthProperty().bind(root.widthProperty().divide(4));
        vBoxesForAnswers.prefHeightProperty().bind(root.heightProperty().divide(4));

        vBoxesForAnswers.getChildren().addAll(hBox1, hBox2);

        BorderPane.setAlignment(nextButton, Pos.CENTER);

        root.getChildren().clear();
        root.setStyle("-fx-background-color: rgb(230,200,210);");

        root.setTop(boxPaneForQuestion);
        root.setRight(nextButton);
        root.setCenter(vBoxForCenterResult);
        root.setBottom(vBoxesForAnswers);

        stage.setScene(scene);
        stage.setTitle("show result");

    }

    public static void showPlaceForFill(BorderPane root,Stage stage,Question question) {
        HBox boxPaneForQuestion = new HBox();

        Label labelNumQuestion = new Label();
        Label labelIch = new Label();

        labelNumQuestion.setText("Q" + (++index));
        labelIch.setText(" ich");
        labelNumQuestion.setTextFill(Color.ORANGE);
        labelIch.setTextFill(Color.BLACK);

        boxPaneForQuestion.setStyle("-fx-background-color: white");
        boxPaneForQuestion.setAlignment(Pos.CENTER);
        boxPaneForQuestion.setSpacing(5);
        boxPaneForQuestion.getChildren().addAll(labelNumQuestion, labelIch);

        Label labelForCorrect = new Label();
        labelForCorrect.setText("The number of right answer is: " + countForRightFillAnswer);
        labelForCorrect.setFont(font);
        labelForCorrect.setTextFill(Color.WHITE);

        Button nextButton = new Button("Next->");
        nextButton.setTextFill(Color.WHITE);
        nextButton.setStyle("-fx-background-color: purple");

        Label labelForRightAnswer = new Label();
        String rightAnswer = quiz.getQuestions().get(index-1).getAnswer();
        labelForRightAnswer.setText(rightAnswer);
        labelForRightAnswer.setTextFill(Color.MAROON);
        labelForRightAnswer.setFont(font);
        labelForRightAnswer.setMinHeight(50);
        HBox hBox = new HBox();
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().add(labelForRightAnswer);

        nextButton.setOnAction(e -> {
            try {
                currentSec = tempForCurrentSec;
                react = 0;
                if(index == quiz.getQuestions().size()){
                    strive = false;
                    pauseForStrive = false;
                    countForRightFillAnswer = 0;
                    totalPage(root,stage);
                }else {
                    pauseForStrive = false;
                    serverShow(stage);
                }
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        });

        BorderPane.setAlignment(nextButton, Pos.CENTER);

        root.getChildren().clear();
        root.setStyle("-fx-background-color: rgb(230,200,210);");

        root.setTop(boxPaneForQuestion);
        root.setRight(nextButton);
        root.setCenter(labelForCorrect);
        root.setBottom(hBox);

        stage.setScene(scene);
        stage.setTitle("show result");
    }

    public synchronized boolean isStrive() {
        return strive;
    }

    public synchronized boolean isPauseForStrive() {
        return pauseForStrive;
    }

    public static void totalPage(BorderPane root,Stage stage){
        root.getChildren().clear();
        root.setStyle("-fx-background-color: midnightBlue");

        Label labelForEnd = new Label();

        if(!players.isEmpty()) {
            int max = Collections.max(players.values());
            List<String> keys = new ArrayList<>();
            for (Entry<String, Integer> entry : players.entrySet()) {
                if (entry.getValue() == max) {
                    keys.add(entry.getKey());
                }
            }


            String listString = keys.stream().map(Object::toString).collect(Collectors.joining(", "));
            labelForEnd.setText(listString);
            labelForEnd.setTextFill(Color.WHITE);

        }

        Button exitForServer = new Button("Exit");
        exitForServer.setOnAction(e->{
            System.exit(0);
        });

        Image image = null;
        try {
            image = new Image(new FileInputStream("src/podium.jpg"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        ImageView imageView = new ImageView(image);
        imageView.fitWidthProperty().bind(root.widthProperty());
        imageView.fitHeightProperty().bind(root.heightProperty());


        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(imageView);

        root.setTop(labelForEnd);
        root.setCenter(stackPane);
        root.setRight(exitForServer);
        stage.setTitle("Total Page");
    }

    public static void dosMusic(){
        mediaFile = new File("src/kahoot_music.mp3");
        media = new Media(mediaFile.toURI().toString());
        mediaPlayer = new MediaPlayer(media);
    }
}
