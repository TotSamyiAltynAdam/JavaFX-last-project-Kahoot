package com.example.thirdproject;

import java.io.*;
import java.net.Socket;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.FontPosture;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.util.Duration;

public class Player extends Application{

    private static Socket socket;
    private static DataOutputStream toServer;
    private static DataInputStream fromServer;
    private static Stage stage;
    private static final String rightAnswer = "You wrote right pinCode!";
    private static String answerForServer = "";

    private static final Font font = Font.font("Times New Roman",FontWeight.BOLD,FontPosture.ITALIC,16);
    private static BorderPane root;
    private static final double WIDTH = 450.;
    private static final double HEIGHT = 450.;
    private static final int numOfButtons = 4;
    private static String username = "";
    private static final String[] colors = {"red","blue","orange","green"};
    private static String chosenColor;
    private static Timeline timeline;

    private static Thread threadForPlayer = new Thread(()->{
        try{
            String s = fromServer.readUTF();
            Platform.runLater(() -> {
                determineQuestion(root, s);
            });
        }catch (IOException e){
            e.printStackTrace();
        }
        while (true) {
            try {
                String messageFromServer = fromServer.readUTF();
                if(messageFromServer.equals("give me answer")){
                    toServer.writeUTF(answerForServer);
                }else if(messageFromServer.equals("time out")){
                    String points = fromServer.readUTF();
                    answerForServer = "";
                    miniResult(root,stage,points);
                    String type = fromServer.readUTF();
                    Platform.runLater(() -> {
                        determineQuestion(root, type);
                    });
                }
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(0);
            }
        }
    });

    @Override
    public void start(Stage stage) throws Exception {
        Player.stage = stage;
        root = new BorderPane();
        connection();
        firstPage(root);
        Scene scene = new Scene(root,WIDTH,HEIGHT);
        stage.setTitle("PinCode");
        stage.setScene(scene);
        stage.show();
        root.requestFocus();
    }

    public static void connection() throws IOException{
        socket = new Socket("localhost", 9898);
        toServer = new DataOutputStream(socket.getOutputStream());
        fromServer = new DataInputStream(socket.getInputStream());
    }

    public static void miniResult(BorderPane root,Stage stage,String points){
        Label labelForMiniResult = new Label();
        labelForMiniResult.setText(points);

        Rectangle smallRectangle= new Rectangle(25,90,60,30);
        smallRectangle.setArcHeight(15);
        smallRectangle.setArcWidth(25);
        smallRectangle.setFill(Color.WHITE);
        smallRectangle.setStroke(Color.color(Math.random(),Math.random(),Math.random()));

        Rectangle bigRectangle= new Rectangle(25,90,120,60);
        bigRectangle.setArcHeight(15);
        bigRectangle.setArcWidth(25);
        bigRectangle.setFill(Color.CORNSILK);
        bigRectangle.setStroke(Color.color(Math.random(),Math.random(),Math.random()));


        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(bigRectangle,smallRectangle,labelForMiniResult);

        Platform.runLater(()->{
            root.getChildren().clear();
            root.setCenter(stackPane);
            root.setStyle("-fx-background-color: cadetBlue");
            stage.setTitle("MiniResult");
        });

    }

    public static void waitingRoom(BorderPane root,String username) throws IOException {
        Label labelForWaiting = new Label();
        labelForWaiting.setText("We are waiting strive from server");

        root.setCenter(labelForWaiting);
        System.out.println(((Label) root.getCenter()).getText());
        stage.setTitle("waiting room");

        KeyFrame keyFrame = new KeyFrame(Duration.millis(100), event -> {
            String accept = null;

            try {
                accept = fromServer.readUTF();
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (accept.equals("strive")) {
                timeline.stop();
                stage.setTitle(username);
                threadForPlayer.start();
            }

        });

        timeline = new Timeline(keyFrame);
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }

    public static void namePane(BorderPane root){
        VBox vBox = new VBox();
        TextField textFieldForPinName = new TextField();
        textFieldForPinName.setPromptText("ENTER NAME");
        textFieldForPinName.setAlignment(Pos.CENTER);
        textFieldForPinName.setMaxWidth(WIDTH/3);
        textFieldForPinName.setMinHeight(HEIGHT/15);

        Button enterButton = new Button("Enter");
        enterButton.setMaxWidth(WIDTH/3);
        enterButton.setMinHeight(HEIGHT/15);
        enterButton.setTextFill(Color.WHITE);
        enterButton.setStyle("-fx-background-color: black");
        enterButton.setFont(font);


        enterButton.setOnAction(e->{
            try {
                toServer.writeUTF(textFieldForPinName.getText());
                toServer.flush();
                username = fromServer.readUTF();
                stage.setTitle(username);
                System.out.println("My name is " + username);

                waitingRoom(root,username);
            }catch(IOException ex){
                ex.getStackTrace();
            }
        });

        vBox.setStyle("-fx-background-color: #8A2BE2");
        vBox.setAlignment(Pos.CENTER);
        vBox.setSpacing(10);
        vBox.getChildren().addAll(textFieldForPinName,enterButton);

        root.setCenter(vBox);
    }

    public static void firstPage(BorderPane root){
        VBox vBox = new VBox();
        TextField textFieldForPinCode = new TextField();
        textFieldForPinCode.setPromptText("GAME PIN");
        textFieldForPinCode.setAlignment(Pos.CENTER);
        textFieldForPinCode.setMaxWidth(WIDTH/3);
        textFieldForPinCode.setMinHeight(HEIGHT/15);

        Button enterButton = new Button("Enter");
        enterButton.setMaxWidth(WIDTH/3);
        enterButton.setMinHeight(HEIGHT/15);
        enterButton.setTextFill(Color.WHITE);
        enterButton.setStyle("-fx-background-color: black");
        enterButton.setFont(font);

        enterButton.setOnAction(e->{
            try {
                toServer.writeInt(Integer.parseInt(textFieldForPinCode.getText()));
                String answerFromServer = fromServer.readUTF();
                if (answerFromServer.equals(rightAnswer)) {
                    System.out.println(answerFromServer);
                    stage.setTitle("Name Pane");
                    namePane(root);
                } else {
                    System.out.println(answerFromServer);
                }
            }catch(IOException ex){
                ex.getStackTrace();
            }
        });

        vBox.setStyle("-fx-background-color: darkBlue");
        vBox.setAlignment(Pos.CENTER);
        vBox.setSpacing(10);
        vBox.getChildren().addAll(textFieldForPinCode,enterButton);
        root.setCenter(vBox);
    }
    public static void determineQuestion(BorderPane root, String type){
        //we need to determine type of question
        if(type.equals("end")){
            totalPageForPlayers();
        }

        if(type.equals("1")){
            fill(root);
        }

        if(type.equals("2")){
            chooseButtons(root);
        }
    }

    public static void chooseButtons(BorderPane root) {
        Button buttonRed = getButton(colors[0]);
        buttonRed.setMinWidth(WIDTH / 2);
        buttonRed.setMaxHeight(HEIGHT / 2);

        Button buttonBlue = getButton(colors[1]);
        buttonBlue.setMinWidth(WIDTH / 2);
        buttonBlue.setMaxHeight(HEIGHT / 2);

        Button buttonOrange = getButton(colors[2]);
        buttonOrange.setMinWidth(WIDTH / 2);
        buttonOrange.setMaxHeight(HEIGHT / 2);

        Button buttonGreen = getButton(colors[3]);
        buttonGreen.setMinWidth(WIDTH / 2);
        buttonGreen.setMaxHeight(HEIGHT / 2);


        HBox hBox1 = new HBox();
        hBox1.setMaxWidth(WIDTH);
        hBox1.setMinHeight(HEIGHT / 2);
        hBox1.setSpacing(5);

        HBox hBox2 = new HBox();
        hBox2.setMaxWidth(WIDTH);
        hBox2.setMinHeight(HEIGHT / 2);
        hBox2.setSpacing(5);

        HBox[] hBoxes = {hBox1, hBox2};

        hBoxes[0 / 2].getChildren().addAll(buttonRed);
        hBoxes[1 / 2].getChildren().addAll(buttonBlue);
        hBoxes[1].getChildren().addAll(buttonOrange);
        hBoxes[3 / 2].getChildren().addAll(buttonGreen);

        VBox vBox = new VBox();
        vBox.setStyle("-fx-background-color: purple");
        vBox.setAlignment(Pos.CENTER);
        vBox.setSpacing(5);
        vBox.getChildren().addAll(hBox1, hBox2);

        answerForServer = "";

        buttonRed.setOnAction(e -> {
            answerForServer = "red";

            buttonRed.setDisable(true);
            buttonBlue.setDisable(true);
            buttonGreen.setDisable(true);
            buttonOrange.setDisable(true);

        });

        buttonBlue.setOnAction(e -> {
            answerForServer = "blue";

            buttonRed.setDisable(true);
            buttonBlue.setDisable(true);
            buttonGreen.setDisable(true);
            buttonOrange.setDisable(true);

        });

        buttonOrange.setOnAction(e -> {
            answerForServer = "orange";

            buttonRed.setDisable(true);
            buttonBlue.setDisable(true);
            buttonGreen.setDisable(true);
            buttonOrange.setDisable(true);
        });

        buttonGreen.setOnAction(e -> {
            answerForServer = "green";

            buttonRed.setDisable(true);
            buttonBlue.setDisable(true);
            buttonGreen.setDisable(true);
            buttonOrange.setDisable(true);
        });

        root.setCenter(vBox);
        stage.setTitle(username + " - test");
    }

    public static void fill(BorderPane root){
        Label label = new Label("Type your answer here");
        label.setFont(font);
        HBox hBox = new HBox();
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().add(label);

        answerForServer = "";

        TextField textField = new TextField();
        textField.setLayoutX(500);
        textField.setLayoutY(500);
        textField.setPrefWidth(350);


        Button submitButton = new Button("Submit");
        submitButton.setFont(font);

        submitButton.setOnAction(e->{
            String answerFromTf = textField.getText();
            answerForServer = answerFromTf;
        });

        root.setStyle("-fx-background-color: lightGoldenRodYellow");
        root.setTop(hBox);
        root.setCenter(textField);
        root.setRight(submitButton);
        stage.setTitle(username  + " - fill");
    }


    public static Button getButton(String color){
        Button button = new Button();

        button.setMaxWidth(WIDTH/2);
        button.setMaxHeight(HEIGHT/2);
        button.setStyle("-fx-background-color: " + color);
        button.setText(color);
        button.setTextFill(Color.WHITE);
        button.setWrapText(true);
        button.setFont(font);

        return button;
    }

    public static BorderPane totalPageForPlayers() {
        root.getChildren().clear();

        Image image = null;
        try {
            image = new Image(new FileInputStream("src/result.png"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        ImageView imageView = new ImageView(image);
        imageView.fitHeightProperty().bind(root.heightProperty().multiply(0.5));
        imageView.fitWidthProperty().bind(root.widthProperty().multiply(0.6));

        Button exitButton = new Button("Exit");

        exitButton.setOnAction(e->{
            System.exit(0);
        });

        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(imageView,exitButton);

        root.setCenter(stackPane);
        stage.setTitle("Total Page");
        return root;
    }

}
