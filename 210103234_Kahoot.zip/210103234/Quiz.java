package com.example.thirdproject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Quiz {
    private Scanner scan = new Scanner(System.in);
    private String name;
    private ArrayList<Question> questions = new ArrayList<>();

    public Quiz(){

    }

    public void setName(String name) {
        System.out.println(name);
    }

    public String getName(){
        return name;
    }

    public void addQuestion(Question q){
        questions.add(q);
    }

    public ArrayList<Question> getQuestions(){
        return questions;
    }

    public static Quiz loadFromFile(String filename) throws IOException, InvalidFormatException {
        Quiz quiz = new Quiz();
        File file = new File(filename);
        quiz.setName(file.getName());

        if(file.length()==0){
            throw new InvalidFormatException("No such file!");
        }

        Scanner scan1 = new Scanner(file);
        ArrayList<String> list = new ArrayList<>();
        Question x;

        while(scan1.hasNext()|| list.size()!=0){
            String s = "";
            if(scan1.hasNext()) {
                s = scan1.nextLine();
            }

            if(!s.isEmpty()){
                list.add(s);
                continue;
            }

            if(list.size()==2){
                x = new FillIn();
                x.setDescription(list.get(0));
                x.setAnswer(list.get(1));
                quiz.addQuestion(x);
            }

            else if(list.size()== Test.numOfOptions+1){
                x = new Test();
                x.setDescription(list.get(0));
                x.setAnswer(list.get(1));
                String[] options = new String[Test.numOfOptions];
                list.remove(0);
                Collections.shuffle(list);
                for(int i=0;i<4;i++){
                    options[i] = list.get(i);
                }

                ((Test)x).setOptions(options);
                quiz.addQuestion(x);
            }

            else{
                throw new InvalidFormatException("Invalid quiz format!");
            }

            list.clear();
        }
        scan1.close();
        return quiz;
    }

    public String toString(){
        return "";
    }

}
