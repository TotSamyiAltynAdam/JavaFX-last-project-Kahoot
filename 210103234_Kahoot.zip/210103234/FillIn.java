package com.example.thirdproject;

public class FillIn extends Question {
    public FillIn(){
        setType(1);
    }

    public String toString(){
        return "";
    }
}
