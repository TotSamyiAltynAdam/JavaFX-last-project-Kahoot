package com.example.thirdproject;

public class Question {
    private String description;
    private String answer;
    private int type;

    public void setDescription(String description){
        this.description = description;
    }

    public void setAnswer(String answer){
        this.answer = answer;
    }

    public void setType(int type){
        this.type = type;
    }

    public String getDescription(){
        return description;
    }

    public String getAnswer(){
        return answer;
    }

    public int getType(){
        return type;
    }

}
