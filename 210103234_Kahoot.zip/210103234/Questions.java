package com.example.thirdproject;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.control.Label;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Questions {
    private Stage stage;
    private BorderPane root;
    private Label labelForTime;
    private Label labelForCountingAnswers;
    private final Font font = Font.font("Times new Roman", FontWeight.BOLD, FontPosture.ITALIC, 18);
    static final String[] colors = {"red", "blue", "orange", "green"};

    private Label labelForQuestions;
    private Quiz quiz;
    private VBox[] vBoxes;
    private int index;

    public Questions(Quiz quiz, BorderPane root, Stage stage, Label labelForTime, Label labelForReact, int index) {
        this.quiz = quiz;
        this.stage = stage;
        this.root = root;
        this.labelForTime = labelForTime;
        this.labelForCountingAnswers = labelForReact;
        this.index = index;
    }

    public BorderPane go() throws FileNotFoundException {
        root = new BorderPane();

        labelForQuestions = new Label(quiz.getQuestions().get(0).getDescription());
        labelForQuestions.setFont(font);
        StackPane stackPaneForQuestions = new StackPane();
        stackPaneForQuestions.getChildren().add(labelForQuestions);

        Circle circle = new Circle(30);
        circle.setFill(Color.RED);
        labelForTime.setFont(font);
        labelForTime.setTextFill(Color.WHITE);

        StackPane stackPaneForTime = new StackPane();
        stackPaneForTime.setMinWidth(100);
        stackPaneForTime.prefHeightProperty().bind(root.heightProperty().multiply(0.5));
        stackPaneForTime.prefWidthProperty().bind(root.widthProperty().multiply(0.2));
        stackPaneForTime.getChildren().addAll(circle, labelForTime);



        StackPane stackPaneForCountAnswers = new StackPane();
//        vBoxForRightArea.prefWidthProperty().bind(root.widthProperty().multiply(0.2));
//        vBoxForRightArea.prefHeightProperty().bind(root.heightProperty().multiply(0.5));
        labelForCountingAnswers.setStyle("-fx-background-color: lightGreen");
        stackPaneForCountAnswers.getChildren().add(labelForCountingAnswers);

        vBoxes = new VBox[quiz.getQuestions().size()];
        int sizeQuestions = quiz.getQuestions().size();
        for (int i = 0; i < sizeQuestions; i++) {
            Question q = quiz.getQuestions().get(i);
            if (q.getType() == 1) {
                vBoxes[i] = getField();
            } else {
                vBoxes[i] = getButtons(quiz.getQuestions().get(i), i);
            }
        }

        determinerTypeForImage(index);
        root.setTop(stackPaneForQuestions);
        root.setLeft(stackPaneForTime);
        root.setRight(stackPaneForCountAnswers);
        root.setBottom(vBoxes[index]);
        Scene scene = new Scene(root, 500, 500);
        stage.setTitle("Kahoot");
        stage.setScene(scene);

        return root;
    }

    public void determinerTypeForImage(int index) throws FileNotFoundException {
        Image image = new Image(new FileInputStream("src/logo.png"));
        ImageView imageView = new ImageView(image);
        imageView.fitHeightProperty().bind(root.heightProperty().multiply(0.5));
        imageView.fitWidthProperty().bind(root.widthProperty().multiply(0.6));

        Image image2 = new Image(new FileInputStream("src/result.jpg"));
        ImageView imageView2 = new ImageView(image2);
        imageView2.fitHeightProperty().bind(root.heightProperty().multiply(0.5));
        imageView2.fitWidthProperty().bind(root.widthProperty().multiply(0.6));

        Question question = quiz.getQuestions().get(index);
        if (question.getType() == 1) {
            root.setCenter(imageView);
        } else if (question.getType() == 2) {
            root.setCenter(imageView2);
        }

        labelForQuestions.setText(quiz.getQuestions().get(index).getDescription());
    }

    public VBox getButtons(Question question, int index) {
        HBox hBox1 = new HBox();
        hBox1.setAlignment(Pos.CENTER);
        hBox1.setSpacing(5);
        hBox1.setMinSize(100, 80);

        HBox hBox2 = new HBox();
        hBox2.setAlignment(Pos.CENTER);
        hBox2.setSpacing(5);
        hBox2.setMinSize(100, 80);

        HBox[] hBoxes = {hBox1, hBox2};

        Test t = (Test)question;

        for (int i = 0; i < 4; i++) {
            Label labelForAnswers = new Label(t.getOptionAt(i));
            labelForAnswers.setFont(font);
            labelForAnswers.prefWidthProperty().bind(hBoxes[i / 2].widthProperty().divide(2));
            labelForAnswers.prefHeightProperty().bind(hBoxes[i / 2].heightProperty());
            labelForAnswers.setStyle("-fx-background-color: " + colors[i]);
            hBoxes[i / 2].getChildren().add(labelForAnswers);
        }

        VBox vBoxesForAnswers = new VBox();
        vBoxesForAnswers.setSpacing(5);
        vBoxesForAnswers.prefWidthProperty().bind(root.widthProperty().divide(4));
        vBoxesForAnswers.prefHeightProperty().bind(root.heightProperty().divide(4));

        vBoxesForAnswers.getChildren().addAll(hBox1, hBox2);
        return vBoxesForAnswers;
    }

    public VBox getField() {
        Label label = new Label("Type your answer in your textField");
        label.setMinHeight(50);

        VBox vBox = new VBox();
        vBox.setSpacing(5);
        vBox.getChildren().add(label);
        return vBox;
    }
}
