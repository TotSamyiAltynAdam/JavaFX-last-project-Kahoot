package com.example.thirdproject;

import java.util.ArrayList;

public class Test extends Question {
    private String[] options;
    public static final int numOfOptions = 4;
    private static ArrayList<String> labels = new ArrayList<>();
    private String temp = "";


    static {
        for(int i=0;i<numOfOptions;i++){
            labels.add(Character.toString('A'+i));
        }
    }

    public Test(){
        setType(2);
    }

    public void setOptions(String[] array){
        options = array;
        for(int i=0;i<4;i++){
            if(array[i] == getAnswer()){
                temp = getAnswer();
                setAnswer(Character.toString(65+i));
            }
        }
    }
    public String getOptionAt(int index){
        return options[index];
    }

    public static String labelAt(int index){
        return labels.get(index);
    }

    public String getTemp(){
        return temp;
    }

    @Override
    public String toString(){
        return "";
    }
}
